#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <pthread.h>



#define MUTEX "mutex"
#define RWLOCK "rwlock"
#define NOSYNC "nosync"
#define WRITE  "write"
#define READ   "read"

pthread_mutex_t mutex;
pthread_rwlock_t rwlock;

void* applyCommands();

/* Function that initializes the Syncstrategy */
void init_SyncStrategy(char* argv){
    if((strcmp(argv,NOSYNC)==0)){
        return;
    }

    if((strcmp(argv,MUTEX)==0)){
            /*starts mutex*/
            if (pthread_mutex_init(&mutex, NULL) != 0){
                printf("\n mutex init failed\n");
                exit(EXIT_FAILURE);
            } 
    }
    if((strcmp(argv,RWLOCK)==0)){
            /*starts rwlock*/
            if (pthread_rwlock_init(&rwlock, NULL) != 0){
                printf("rwlock init failed\n");
                exit(EXIT_FAILURE);
            } 
    }
}

/* Function that destroys the initialization of the Syncstrategy */
void destroy_SyncStrategy(char *argv){
    int err;
    if((strcmp(argv,MUTEX)==0)){
        /*destroys mutex*/
        err = pthread_mutex_destroy(&mutex);
        if(err != 0){
            perror("Destruction failed (MUTEX)\n");
            exit(EXIT_FAILURE);
        }
        return;
    }
    if((strcmp(argv,RWLOCK)==0)){ 
        /*destroys rwlock*/
        err = pthread_rwlock_destroy(&rwlock);
        if(err != 0){
            perror("Destruction failed (RWLOCK)\n");
            exit(EXIT_FAILURE);
        }
        return;
    }
}

/* Function that performs locks given the strategy*/
void lock(char* strategy,char* argv){
    int err;
    if((strcmp(strategy,NOSYNC)==0))return;

    if((strcmp(strategy,MUTEX)==0)){
        err = pthread_mutex_lock(&mutex);
        if(err !=0){
            perror("Lock failed(Mutex)\n");
            exit(EXIT_FAILURE);
        }
        return;
    }
    
    if((strcmp(strategy,RWLOCK)==0)){
        if((strcmp(argv,WRITE)==0)){
            err=pthread_rwlock_wrlock(&rwlock);
            if(err != 0){
                perror("Lock failed(RWLOCK)(WRITE)\n");
                exit(EXIT_FAILURE);
            }
        return;
        }
        if((strcmp(argv,READ)==0)){
            err = pthread_rwlock_rdlock(&rwlock);
            if(err != 0){
                perror("Lock failed(RWLOCK)(READ)\n");
                exit(EXIT_FAILURE);
            }
        }
        return;
    }
}

/* Function that performs unlocks given the strategy*/
void unlock(char* strategy){
    int err;
    if((strcmp(strategy,NOSYNC)==0))return;

    /* Unlocks mutexs*/
    if((strcmp(strategy,MUTEX)==0)){
        err=pthread_mutex_unlock(&mutex);
        if(err != 0){
            perror("Unlock failed (MUTEX)\n");
            exit(EXIT_FAILURE);
        }
        return;
    }
    /*Unlocks Rwlocks*/
    if((strcmp(strategy,RWLOCK)==0)){
        err=pthread_rwlock_unlock(&rwlock);
        if(err != 0){
            perror("Unlock failed (RWLOCK)\n");
            exit(EXIT_FAILURE);
        }
        return;
    }
}


/* Function that performs the global mutex locks given the strategy*/
void lock_global(char* argv){
    if((strcmp(argv,NOSYNC)==0)){ 
        return;
    }
    if((strcmp(argv,RWLOCK)==0)){
        /* if syncstrat = RWLOCK
           MUTEX has to be initiated*/
        if (pthread_mutex_init(&mutex, NULL) != 0){
                printf("\n mutex init failed\n");
                exit(EXIT_FAILURE);
            }
        lock(MUTEX,WRITE); 
        return;
    }
    if((strcmp(argv,MUTEX)==0)){
        lock(MUTEX,WRITE);
        return;
    }
}

/* Unlocks global MUTEX */
void unlock_global(char* strategy){
    if((strcmp(strategy,NOSYNC)==0))return;

    else unlock(MUTEX);
}