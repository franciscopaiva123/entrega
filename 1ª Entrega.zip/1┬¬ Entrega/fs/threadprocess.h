#ifndef THREADPROCESS_H
#define THREADPROCESS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <pthread.h>


#define MUTEX "mutex"
#define RWLOCK "rwlock"
#define NOSYNC "nosync"
#define WRITE "write"
#define READ "read"

pthread_mutex_t mutex;
pthread_rwlock_t rwlock;


void init_SyncStrategy(char* argv);
void destroy_SyncStrategy(char *argv);
void lock(char* strategy,char* argv);
void unlock(char* strategy);
void lock_global(char* argv);
void unlock_global(char* strategy);


#endif
