/* Sistemas Operativos 2020-21
   Projeto 1
   Francisco Paiva 96737
   Joao Rebolo 96748
*/

#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <string.h>
#include <sys/time.h>
#include <pthread.h>
#include <ctype.h>
#include "fs/threadprocess.h"
#include "fs/operations.h"

#define MAX_COMMANDS 150000
#define MAX_INPUT_SIZE 100
#define MUTEX "mutex"
#define RWLOCK "rwlock"
#define NOSYNC "nosync"
#define WRITE  "write"
#define READ   "read"

int numberThreads = 0;
struct timeval tvalBefore;

char inputCommands[MAX_COMMANDS][MAX_INPUT_SIZE];
int numberCommands = 0;
int headQueue = 0;

char strat[256];


pthread_mutex_t mutex;
pthread_rwlock_t rwlock;


void* applyCommands();

/* Function that counts the execution time of the program*/
void count_time(){
    struct timeval tvalAfter;
    gettimeofday(&tvalAfter, NULL);
    
    long seconds = (tvalAfter.tv_sec - tvalBefore.tv_sec);
    long micros = ((seconds * 1000000) + tvalAfter.tv_usec)-(tvalBefore.tv_usec);

    printf("TecnicoFS completed in %ld.%.4ld seconds.\n",seconds, micros);
}


/* Destroys global MUTEX*/
void destroys_global(){
    int err;

    if((strcmp(strat,NOSYNC)==0))return;

    if((strcmp(strat,MUTEX)==0))return;

    if((strcmp(strat,RWLOCK)==0)){
        /*destroys mutex*/
        err = pthread_mutex_destroy(&mutex);
        if(err != 0){
            perror("Destruction failed (MUTEX)");
            exit(EXIT_FAILURE);
        }
    }

}

/* Function that checks input writen in the terminal */
void checkinput(int argc,char* argv){
    if(argc != 5){
        fprintf(stderr, "Error: Number of arguments is incorrect\n");
        exit(EXIT_SUCCESS);
    }
    if(numberThreads < 1){
        fprintf(stderr, "Error: Amount of threads is incorrect\n");
        exit(EXIT_SUCCESS);
    }

   if((strcmp(argv,NOSYNC)==0) && (numberThreads != 1)){
        fprintf(stderr, "Error: Number of threads doesnt match synchstrategy\n");
        exit(EXIT_SUCCESS);
    }

    if(strcmp(argv,NOSYNC)!=0 && strcmp(argv,MUTEX)!=0 && strcmp(argv,RWLOCK)!=0){
         fprintf(stderr, "Error: Syncstrategy unrecognized\n");
        exit(EXIT_SUCCESS);
    }
}

/* Function that creates and joins threads*/
void init_threads(){
    int err;
    pthread_t tid[numberThreads];
    /* Creates threads*/
    for(int i=0; i < numberThreads;i++){
        err = pthread_create(&(tid[i]), NULL, applyCommands, NULL);
        if (err != 0){
            perror("Can't create thread");
            exit(EXIT_FAILURE);
        }
    }
    /* Joins threads*/
    for(int i=0; i < numberThreads;i++){
        if(pthread_join(tid[i], NULL)){
            perror("Can't join thread");
            exit(EXIT_FAILURE);
        }
    }   
}

int insertCommand(char* data) {
    if(numberCommands != MAX_COMMANDS) {
        strcpy(inputCommands[numberCommands++], data);
        return 1;
    }
    return 0;
}

char* removeCommand() {
    if(numberCommands > 0){
        numberCommands--;
        return inputCommands[headQueue++];  
    }
    return NULL;
    

}

void errorParse(){
    fprintf(stderr, "Error: command invalid\n");
    exit(EXIT_FAILURE);
}

void processInput(char* filename){
    char line[MAX_INPUT_SIZE];


    /* break loop with ^Z or ^D */
    FILE *file = fopen(filename, "r");
    
    if(file == NULL){
        fprintf(stderr, "Error: Problem with input file\n");
        exit(EXIT_SUCCESS);
        return;
    }
    
    while (fgets(line, sizeof(line)/sizeof(char), file)) {
        char token, type;
        char name[MAX_INPUT_SIZE];

        int numTokens = sscanf(line, "%c %s %c", &token, name, &type);

        /* perform minimal validation */
        if (numTokens < 1) {
            continue;
        }
        switch (token) {
            case 'c':
                if(numTokens != 3)
                    errorParse();
                if(insertCommand(line))
                    break;
                return;
            
            case 'l':
                if(numTokens != 2)
                    errorParse();
                if(insertCommand(line))
                    break;
                return;
            
            case 'd':
                if(numTokens != 2)
                    errorParse();
                if(insertCommand(line))
                    break;
                return;
            
            case '#':
                break;
            
            default: { /* error */
                errorParse();
            }
        }
    }
    fclose(file);
}

void* applyCommands(){
        while(1){
            lock_global(strat);
            char* command = removeCommand();
            if (command == NULL){
                unlock_global(strat);
                break;
            }
            unlock_global(strat);
            
            char token, type;
            char name[MAX_INPUT_SIZE];
            int numTokens = sscanf(command, "%c %s %c", &token, name, &type);
            if (numTokens < 2) {
                fprintf(stderr, "Error: invalid command in Queue\n");
                exit(EXIT_FAILURE);
            }

            int searchResult;
            switch (token) {
                case 'c':
                    switch (type){
                        case 'f':
                                lock(strat,WRITE);
                                printf("Create file: %s\n", name);
                                create(name, T_FILE);
                                unlock(strat);
                                break;

                        case 'd':
                                lock(strat,WRITE);
                                printf("Create directory: %s\n", name);
                                create(name, T_DIRECTORY);
                                unlock(strat);
                                break;
                            
                        default:
                                fprintf(stderr, "Error: invalid node type\n");
                                exit(EXIT_FAILURE);
                    }
                    break;
                case 'l':
                        lock(strat,READ);    
                        searchResult = lookup(name);
                        if (searchResult >= 0){
                            printf("Search: %s found\n", name);
                        }
                        else{
                            (printf("Search: %s not found\n", name));
                        }   
                        unlock(strat);
                        break;

                case 'd':
                        lock(strat,WRITE);
                        printf("Delete: %s\n", name);
                        delete(name);
                        unlock(strat);
                        break;
                default: /* error */
                        fprintf(stderr, "Error: command to apply\n");
                        exit(EXIT_FAILURE);                   
            }
        }
    }

int main(int argc, char* argv[]) {
    gettimeofday(&tvalBefore, NULL);
    
    /*thread variable*/
    numberThreads = atoi(argv[3]);
    
    /*Variable that saves the Syncstrategy*/
    strcpy(strat,argv[4]);
    
    /*checks if input is correct*/
    checkinput(argc,argv[4]);

    /* initiate filesystem */
    init_fs();
    
    /* initiates strategy*/
    init_SyncStrategy(argv[4]);
    
    /* process input */
    processInput(argv[1]);  
    
    /* initiates threads*/
    init_threads();
    
    /* prints tree */
    print_tecnicofs_tree(argv[2]);
    
    /* destroys the initialization of the Syncstrategy */
    destroy_SyncStrategy(argv[4]);

    /* destroys global MUTEX (given that case)*/
    destroys_global();
    
    /* release allocated memory */
    destroy_fs();
    /* prints execution time*/
    count_time();
    
    exit(EXIT_SUCCESS);
}
